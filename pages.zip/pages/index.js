import { useEffect, useState } from 'react';
import Head from 'next/head';


export default function Home() {
  const [enrollment, setEnrollment] = useState('');
  const [secretCode, setSecretCode] = useState(''); // ✅ NEW
  const [filteredData, setFilteredData] = useState(null);
  const [loading, setLoading] = useState(false);

  // Autofocus enrollment input on page load
  useEffect(() => {
    document.getElementById("enrollment-input")?.focus();
  }, []);


  const handleSearch = async () => {
    setLoading(true);
  
    try {
      const res = await fetch("/api/fetchAssignments");

      if (!res.ok) {
        throw new Error(`API error: ${res.status} ${res.statusText}`);
      }
  
      const { assignments, auth } = await res.json(); // ✅ UPDATED: expect both datasets
  
      if (!assignments || !auth) throw new Error("Missing data from API");

      // ✅ Secret Code Verification Block
      const authHeader = auth[0];
      const authRows = auth.slice(1);
      const authMatch = authRows.find(
        (row) =>
          row[0]?.trim() === enrollment.trim() &&
          row[1]?.trim() === secretCode.trim()
      );

      if (!authMatch) {
        alert("Invalid enrollment number or secret code.");
        setFilteredData(null);
        return;
      }

      // ✅ Process assignment data
      const headers = assignments[0];
      const rows = assignments.slice(1);
  
      const matches = rows.filter(
        (row) => row[0]?.trim() === enrollment.trim()
      );
  
      if (!matches.length) {
        setFilteredData(null);
        return;
      }
  
      const assignmentMap = new Map();
      matches.forEach((row) => {
        const assignment = row[4];
        const marks = parseFloat(row[5]);
        if (!assignmentMap.has(assignment) || marks > assignmentMap.get(assignment)) {
          assignmentMap.set(assignment, marks);
        }
      });
  
      const bestAttempts = Array.from(assignmentMap.entries()).map(
        ([assignment, marks]) => ({ assignment, marks })
      ).sort((a, b) => Number(a.assignment) - Number(b.assignment));
  
      const totalMarks = bestAttempts.reduce((sum, a) => sum + a.marks, 0);
      const averageMarks = (totalMarks / bestAttempts.length).toFixed(2);
  
      const result = {
        name: matches[0][1]?.trim() || "Unknown",
        phone: matches[0][3]?.trim() || "N/A",
        assignments: bestAttempts,
        totalMarks,
        averageMarks,
        attempted: bestAttempts.length,
      };
  
      setFilteredData(result);
  
    } catch (err) {
      alert("An error occurred while fetching assignment data. Check console for details.");
      console.error("❌", err); // ✅ NEW: helpful debug log
      setFilteredData(null);
    } finally {
      setLoading(false);
    }
  };

  // Main component
  return (
    <>
      <Head>
        <title>Assignment Dashboard</title>
        <meta name="description" content="Check student assignment marks and attempts" />
      </Head>

      <main className="dashboard-container">
        <h1 className="dashboard-header">Assignment Dashboard</h1>

        <div className="input-row">
          <input
            id="enrollment-input" //  for autofocus
            className="input-field"
            placeholder="Enter Enrollment No"
            value={enrollment}
            onChange={(e) => setEnrollment(e.target.value)}
            onKeyDown={(e) => e.key === 'Enter' && handleSearch()} // ✅ for enter to submit
          />
          <input
            className="input-field" // ✅ NEW: Secret code input
            placeholder="Enter Secret Code"
            value={secretCode}
            onChange={(e) => setSecretCode(e.target.value)}
            onKeyDown={(e) => e.key === 'Enter' && handleSearch()} // ✅ optional
          />
          <button onClick={handleSearch} className="search-button">
            Search
          </button>
        </div>

        {loading && <p className="text-gray-500 text-center">Loading...</p>}

        {filteredData && (
          <>
            <div className="animate-fadeInUp student-card">
            <h2 className="student-info-title">Student Info</h2>

            <div className="student-info-grid">
              <div>
                <p>
                  <span className="student-info-label">Name:</span>{' '}
                  <span className="student-info-value">{filteredData.name}</span>
                </p>
              </div>
              <div>
                <p>
                  <span className="student-info-label">Phone:</span>{' '}
                  <span className="student-info-value">{filteredData.phone}</span>
                </p>
              </div>
              <div>
                <p>
                  <span className="student-info-label">Total Marks:</span>{' '}
                  <span className="student-info-value">{filteredData.totalMarks}/{filteredData.attempted *100}</span>
                </p>
              </div>
              <div>
                <p>
                  <span className="student-info-label">Percentage:</span>{' '}
                  <span className="student-info-value">{filteredData.averageMarks}%</span>
                </p>
            </div>
            
            </div>
              <table className="assignment-table">
                <thead>
                  <tr>
                    <th className="assignment-th">Assignment</th>
                    <th className="assignment-th">Best Marks</th>
                  </tr>
                </thead>
                <tbody>
                  {filteredData.assignments.map((a, i) => (
                    <tr key={i} className={i % 2 === 0 ? "assignment-td-even" : "assignment-td-odd"}>
                      <td className="assignment-td">{a.assignment}</td>
                      <td className="assignment-td">{a.marks}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
            <button
              className="print-results-button"
              onClick={() => window.print()}
              style={{ display: 'block', margin: '0 auto' }}
            >
              Print Results
            </button>
          </>
        )}

        {!loading && filteredData === null && enrollment && (
          <p className="error-message">
            No records found for Enrollment No: <strong>{enrollment}</strong>
          </p>
        )}
      </main>
    </>
  );
}
